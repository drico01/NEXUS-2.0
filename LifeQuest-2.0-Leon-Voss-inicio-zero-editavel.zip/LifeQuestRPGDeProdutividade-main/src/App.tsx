import { FormEvent, ReactNode, useEffect, useMemo, useState } from "react";

type Tab = "home" | "missions" | "map" | "character" | "inventory";
type Mission = {
  id: number;
  title: string;
  description: string;
  category: string;
  time: string;
  difficulty: string;
  xp: number;
  gold: number;
  type: "Diária" | "Semanal" | "Especial";
};

const icons: Record<string, ReactNode> = {
  home: (
    <>
      <path d="m3 10 9-7 9 7" />
      <path d="M5 9v11h14V9M9 20v-6h6v6" />
    </>
  ),
  sword: (
    <>
      <path d="m14 4 6-2-2 6L8 18l-4 2 2-4Z" />
      <path d="m12 10 4 4M5 15l4 4" />
    </>
  ),
  map: (
    <>
      <path d="m3 6 5-3 8 3 5-3v15l-5 3-8-3-5 3Z" />
      <path d="M8 3v15M16 6v15" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21a8 8 0 0 1 16 0" />
    </>
  ),
  bag: (
    <>
      <path d="M5 8h14l1 13H4Z" />
      <path d="M9 9V6a3 3 0 0 1 6 0v3" />
    </>
  ),
  bolt: <path d="m13 2-8 12h7l-1 8 8-12h-7Z" />,
  coin: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M14.5 8.5c-.5-.4-1.3-.6-2.2-.6-1.3 0-2.3.7-2.3 1.7 0 2.7 5 1.3 5 4 0 1.1-1 1.8-2.5 1.8-.9 0-1.8-.3-2.5-.8M12.5 6v12" />
    </>
  ),
  flame: (
    <path d="M12 22c4 0 7-3 7-7 0-3-1.5-5.5-4-8 .1 3-1.4 4-2.4 4.8.2-4-2-7-5.6-9.8.2 5-2 7-2 11 0 5 3 9 7 9Z" />
  ),
  check: <path d="m5 12 4 4L19 6" />,
  plus: <path d="M12 5v14M5 12h14" />,
  calendar: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="2" />
      <path d="M16 3v4M8 3v4M3 10h18" />
    </>
  ),
  chart: (
    <>
      <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
    </>
  ),
  arrow: <path d="m9 18 6-6-6-6" />,
  lock: (
    <>
      <rect x="5" y="10" width="14" height="11" rx="2" />
      <path d="M8 10V7a4 4 0 0 1 8 0v3" />
    </>
  ),
  close: <path d="m6 6 12 12M18 6 6 18" />,
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </>
  ),
  star: <path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9Z" />,
  trophy: (
    <>
      <path d="M8 4h8v5a4 4 0 0 1-8 0Z" />
      <path d="M8 6H4v2a4 4 0 0 0 4 4M16 6h4v2a4 4 0 0 1-4 4M12 13v5M8 21h8M9 18h6" />
    </>
  ),
  edit: (
    <>
      <path d="m14 5 5 5L9 20H4v-5Z" />
      <path d="m13 6 5 5" />
    </>
  ),
  trash: (
    <>
      <path d="M4 7h16M9 7V4h6v3M7 7l1 14h8l1-14M10 11v6M14 11v6" />
    </>
  ),
};

function Icon({ name, size = 20 }: { name: string; size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      {icons[name]}
    </svg>
  );
}

const initialMissions: Mission[] = [
  {
    id: 1,
    title: "Despertar do guerreiro",
    description: "Complete 30 minutos de treino físico.",
    category: "Saúde",
    time: "07:00",
    difficulty: "Médio",
    xp: 120,
    gold: 35,
    type: "Diária",
  },
  {
    id: 2,
    title: "Arquivo de conhecimento",
    description: "Leia 20 páginas do livro atual.",
    category: "Conhecimento",
    time: "12:30",
    difficulty: "Fácil",
    xp: 80,
    gold: 20,
    type: "Diária",
  },
  {
    id: 3,
    title: "Modo foco profundo",
    description: "Trabalhe 50 minutos sem distrações.",
    category: "Trabalho",
    time: "14:00",
    difficulty: "Difícil",
    xp: 160,
    gold: 45,
    type: "Diária",
  },
  {
    id: 4,
    title: "Refúgio restaurador",
    description: "Prepare o ambiente e durma antes das 23h.",
    category: "Bem-estar",
    time: "22:30",
    difficulty: "Médio",
    xp: 100,
    gold: 30,
    type: "Diária",
  },
  {
    id: 5,
    title: "Ordem no acampamento",
    description: "Organize o espaço por 15 minutos.",
    category: "Disciplina",
    time: "18:00",
    difficulty: "Fácil",
    xp: 60,
    gold: 15,
    type: "Semanal",
  },
  {
    id: 6,
    title: "Desafio do monólito",
    description: "Conclua 5 missões em um único dia.",
    category: "Disciplina",
    time: "Hoje",
    difficulty: "Épico",
    xp: 300,
    gold: 100,
    type: "Especial",
  },
];

function readStoredNumber(key: string, fallback: number) {
  const value = localStorage.getItem(key);
  if (value === null) return fallback;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function readStoredArray<T>(key: string, fallback: T[]): T[] {
  try {
    const value = localStorage.getItem(key);
    return value === null ? fallback : (JSON.parse(value) as T[]);
  } catch {
    return fallback;
  }
}

const categoryColors: Record<string, string> = {
  Saúde: "#39e5b4",
  Conhecimento: "#8b7cff",
  Trabalho: "#37b9ff",
  "Bem-estar": "#ff6fb5",
  Disciplina: "#ffb547",
};

function Badge({ children, tone = "purple" }: { children: ReactNode; tone?: string }) {
  return <span className={`badge ${tone}`}>{children}</span>;
}

function AppHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <header className="page-header">
      <div>
        <span className="eyebrow">LIFEQUEST // PLAYER 01</span>
        <h1>{title}</h1>
        {subtitle && <p>{subtitle}</p>}
      </div>
      <button className="avatar-mini" aria-label="Perfil">
        <span>LV</span>
        <i />
      </button>
    </header>
  );
}

export default function App() {
  const [tab, setTab] = useState<Tab>("home");
  const [xp, setXp] = useState(() => readStoredNumber("lq2-xp", 0));
  const [gold, setGold] = useState(() => readStoredNumber("lq2-gold", 0));
  const [completed, setCompleted] = useState<number[]>(() =>
    readStoredArray<number>("lq2-done", []),
  );
  const [missions, setMissions] = useState<Mission[]>(() =>
    readStoredArray<Mission>("lq2-missions", initialMissions),
  );
  const [missionType, setMissionType] = useState("Diária");
  const [heroProfile, setHeroProfile] = useState(() => {
    try { return JSON.parse(localStorage.getItem("lq2-hero-profile") || "null") || { name: "Leon Voss", hair: "Prateado", eyes: "Violeta", armor: "Ébano", emblem: "LV" }; }
    catch { return { name: "Leon Voss", hair: "Prateado", eyes: "Violeta", armor: "Ébano", emblem: "LV" }; }
  });
  const [attributeXp, setAttributeXp] = useState<Record<string, number>>(() => {
    try { return JSON.parse(localStorage.getItem("lq2-attribute-xp") || "{}"); } catch { return {}; }
  });
  const [overlay, setOverlay] = useState<"mission" | "calendar" | "reward" | null>(null);
  const [editingMission, setEditingMission] = useState<Mission | null>(null);
  const [reward, setReward] = useState<Mission | null>(null);
  const [charView, setCharView] = useState<"atributos" | "conquistas" | "estatísticas">(
    "atributos",
  );

  useEffect(() => {
    localStorage.setItem("lq2-xp", String(xp));
    localStorage.setItem("lq2-gold", String(gold));
    localStorage.setItem("lq2-done", JSON.stringify(completed));
    localStorage.setItem("lq2-missions", JSON.stringify(missions));
    localStorage.setItem("lq2-hero-profile", JSON.stringify(heroProfile));
    localStorage.setItem("lq2-attribute-xp", JSON.stringify(attributeXp));
  }, [xp, gold, completed, missions, heroProfile, attributeXp]);

  const todayDone = missions.filter(
    (m) => m.type === "Diária" && completed.includes(m.id),
  ).length;
  const dailyTotal = missions.filter((m) => m.type === "Diária").length;
  const level = Math.floor(xp / 1000) + 1;
  const levelXp = xp % 1000;

  function completeMission(m: Mission) {
    if (completed.includes(m.id)) return;
    setCompleted((v) => [...v, m.id]);
    setXp((v) => v + m.xp);
    setGold((v) => v + m.gold);
    const attribute = m.category === "Saúde" ? "VITALIDADE" : m.category === "Conhecimento" ? "INTELIGÊNCIA" : m.category === "Trabalho" ? "FOCO" : m.category === "Bem-estar" ? "FORÇA" : "DISCIPLINA";
    setAttributeXp((v) => ({ ...v, [attribute]: (v[attribute] || 0) + m.xp }));
    setReward(m);
    setOverlay("reward");
  }

  function createMission(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const next: Mission = {
      id: editingMission?.id ?? Date.now(),
      title: String(fd.get("title")),
      description: String(fd.get("description")),
      category: String(fd.get("category")),
      time: String(fd.get("time") || "Livre"),
      difficulty: String(fd.get("difficulty")),
      xp: Number(
        fd.get("difficulty") === "Difícil" ? 150 : fd.get("difficulty") === "Médio" ? 100 : 60,
      ),
      gold: Number(
        fd.get("difficulty") === "Difícil" ? 40 : fd.get("difficulty") === "Médio" ? 25 : 15,
      ),
      type: (fd.get("type") as Mission["type"]) || editingMission?.type || "Diária",
    };
    if (editingMission) setMissions((v) => v.map((m) => m.id === editingMission.id ? next : m));
    else setMissions((v) => [...v, next]);
    setEditingMission(null);
    setOverlay(null);
  }

  function buy(name: string, price: number) {
    if (gold < price) return;
    setGold((v) => v - price);
    setReward({ ...initialMissions[0], title: name, xp: 0, gold: -price });
    setOverlay("reward");
  }

  const screen = {
    home: (
      <Home
        xp={levelXp}
        level={level}
        gold={gold}
        done={todayDone}
        total={dailyTotal}
        missions={missions}
        completed={completed}
        complete={completeMission}
        go={setTab}
        open={setOverlay}
      />
    ),
    missions: (
      <Missions
        missions={missions}
        completed={completed}
        type={missionType}
        setType={setMissionType}
        complete={completeMission}
        create={() => setOverlay("mission")}
        remove={(id) => setMissions((v) => v.filter((m) => m.id !== id))}
        edit={(m) => { setEditingMission(m); setOverlay("mission"); }}
      />
    ),
    map: <MapScreen xp={xp} />,
    character: <Character view={charView} setView={setCharView} completed={completed.length} xp={xp} profile={heroProfile} setProfile={setHeroProfile} attributeXp={attributeXp} level={level} />, 
    inventory: <Inventory gold={gold} buy={buy} />,
  }[tab];

  return (
    <div className="app-shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <div className="scanlines" />
      <main className="screen" key={tab}>
        {screen}
      </main>
      <nav className="bottom-nav">
        {(
          [
            ["home", "home", "Início"],
            ["missions", "sword", "Missões"],
            ["map", "map", "Mapa"],
            ["character", "user", "Herói"],
            ["inventory", "bag", "Inventário"],
          ] as [Tab, string, string][]
        ).map(([id, icon, label]) => (
          <button key={id} className={tab === id ? "active" : ""} onClick={() => setTab(id)}>
            <Icon name={icon} />
            <span>{label}</span>
          </button>
        ))}
      </nav>

      {overlay === "mission" && (
        <MissionModal close={() => { setOverlay(null); setEditingMission(null); }} submit={createMission} mission={editingMission} />
      )}
      {overlay === "calendar" && (
        <CalendarModal close={() => setOverlay(null)} missions={missions} completed={completed} />
      )}
      {overlay === "reward" && reward && (
        <RewardModal reward={reward} close={() => setOverlay(null)} />
      )}
    </div>
  );
}

function Home({ xp, level, gold, done, total, missions, completed, complete, go, open }: any) {
  const daily = missions.filter((m: Mission) => m.type === "Diária");
  return (
    <div className="home-page">
      <AppHeader title="Central do jogador" />
      <section className="hero glass">
        <div className="hero-copy">
          <Badge>JORNADA ATIVA</Badge>
          <h2>
            Bem-vindo de volta,
            <br />
            <strong>Leon Voss.</strong>
          </h2>
          <p>Sua próxima evolução começa agora.</p>
          <button className="primary" onClick={() => go("missions")}>
            <Icon name="bolt" size={18} /> INICIAR JORNADA <Icon name="arrow" size={17} />
          </button>
        </div>
        <div className="avatar-orbit">
          <div className="orbit o1" />
          <div className="orbit o2" />
          <div className="hero-avatar">
            <span>LV</span>
            <small>
              NÍVEL
              <br />
              {level}
            </small>
          </div>
        </div>
      </section>

      <section className="stats-row">
        <div className="stat glass">
          <Icon name="coin" />
          <div>
            <span>GOLD</span>
            <strong>{gold.toLocaleString("pt-BR")}</strong>
          </div>
        </div>
        <div className="stat glass">
          <Icon name="flame" />
          <div>
            <span>SEQUÊNCIA</span>
            <strong>
              0 <small>dias</small>
            </strong>
          </div>
        </div>
        <div className="stat glass">
          <Icon name="trophy" />
          <div>
            <span>PATENTE</span>
            <strong>Recruta</strong>
          </div>
        </div>
      </section>

      <section className="xp-panel glass">
        <div className="panel-title">
          <span>PROGRESSO DO NÍVEL</span>
          <strong>
            {xp} <small>/ 1.000 XP</small>
          </strong>
        </div>
        <div className="progress">
          <i style={{ width: `${xp / 10}%` }} />
        </div>
        <p>
          <Icon name="bolt" size={14} /> Faltam {1000 - xp} XP para alcançar o nível {level + 1}
        </p>
      </section>

      <div className="section-heading">
        <div>
          <span>OBJETIVOS DE HOJE</span>
          <h3>Missões em andamento</h3>
        </div>
        <button onClick={() => go("missions")}>
          Ver todas <Icon name="arrow" size={15} />
        </button>
      </div>
      <div className="daily-progress glass">
        <div className="ring" style={{ "--p": `${(total ? done / total : 0) * 360}deg` } as any}>
          <strong>
            {done}/{total}
          </strong>
        </div>
        <div>
          <strong>{done === total ? "Dia conquistado" : "Continue avançando"}</strong>
          <p>{Math.max(0, total - done)} missões entre você e a vitória de hoje.</p>
        </div>
      </div>
      <div className="mission-stack">
        {daily.slice(0, 3).map((m: Mission) => (
          <MissionCard
            key={m.id}
            mission={m}
            done={completed.includes(m.id)}
            complete={() => complete(m)}
            compact
          />
        ))}
      </div>

      <div className="quick-grid">
        <button className="quick glass" onClick={() => open("calendar")}>
          <Icon name="calendar" />
          <span>
            <strong>Calendário</strong>
            <small>Planeje sua semana</small>
          </span>
          <Icon name="arrow" size={16} />
        </button>
        <button className="quick glass" onClick={() => go("character")}>
          <Icon name="chart" />
          <span>
            <strong>Estatísticas</strong>
            <small>Veja sua evolução</small>
          </span>
          <Icon name="arrow" size={16} />
        </button>
      </div>
      <section className="next-reward glass">
        <div className="reward-icon">
          <Icon name="trophy" />
        </div>
        <div>
          <span>PRÓXIMA RECOMPENSA</span>
          <strong>Baú do Explorador</strong>
          <p>Complete mais 2 missões para desbloquear.</p>
        </div>
        <div className="mini-progress">
          <i style={{ width: "66%" }} />
        </div>
      </section>
    </div>
  );
}

function Missions({ missions, completed, type, setType, complete, create, remove, edit }: any) {
  const filtered = missions.filter((m: Mission) => m.type === type);
  return (
    <div>
      <AppHeader title="Missões" subtitle="Escolha seus desafios. Evolua no seu ritmo." />
      <div className="tab-switch">
        {["Diária", "Semanal", "Especial"].map((t) => (
          <button onClick={() => setType(t)} className={type === t ? "active" : ""} key={t}>
            {t}s
          </button>
        ))}
      </div>
      <section className="mission-summary glass">
        <div>
          <span>PROGRESSO {type.toUpperCase()}</span>
          <strong>
            {filtered.filter((m: Mission) => completed.includes(m.id)).length} de {filtered.length}
          </strong>
        </div>
        <div className="progress">
          <i
            style={{
              width: `${filtered.length ? (filtered.filter((m: Mission) => completed.includes(m.id)).length / filtered.length) * 100 : 0}%`,
            }}
          />
        </div>
        <p>Você está construindo consistência. Cada passo conta.</p>
      </section>
      <div className="filter-row">
        <span>{filtered.length} MISSÕES DISPONÍVEIS</span>
        <button>
          <Icon name="chart" size={16} /> Filtros
        </button>
      </div>
      <div className="mission-stack full">
        {filtered.map((m: Mission) => (
          <div className="mission-wrap" key={m.id}>
            <MissionCard mission={m} done={completed.includes(m.id)} complete={() => complete(m)} />
            <button className="edit-mission" onClick={() => edit(m)} aria-label="Editar missão"><Icon name="edit" size={15} /></button>
            <button
              className="delete-mission"
              onClick={() => remove(m.id)}
              aria-label="Excluir missão"
            >
              <Icon name="trash" size={15} />
            </button>
          </div>
        ))}
      </div>
      <button className="fab" onClick={create}>
        <Icon name="plus" /> <span>NOVA MISSÃO</span>
      </button>
    </div>
  );
}

function MissionCard({
  mission: m,
  done,
  complete,
  compact = false,
}: {
  mission: Mission;
  done: boolean;
  complete: () => void;
  compact?: boolean;
}) {
  return (
    <article
      className={`mission-card glass ${done ? "completed" : ""} ${compact ? "compact" : ""}`}
    >
      <div className="mission-symbol" style={{ "--cat": categoryColors[m.category] } as any}>
        <Icon
          name={
            m.category === "Conhecimento" ? "star" : m.category === "Trabalho" ? "bolt" : "sword"
          }
        />
      </div>
      <div className="mission-body">
        <div className="mission-meta">
          <Badge tone={m.difficulty === "Épico" ? "gold" : "purple"}>{m.difficulty}</Badge>
          <span style={{ color: categoryColors[m.category] }}>{m.category}</span>
        </div>
        <h4>{m.title}</h4>
        {!compact && <p>{m.description}</p>}
        <div className="mission-rewards">
          <span>
            <Icon name="clock" size={14} />
            {m.time}
          </span>
          <span>
            <Icon name="bolt" size={14} />
            {m.xp} XP
          </span>
          <span>
            <Icon name="coin" size={14} />
            {m.gold}
          </span>
        </div>
      </div>
      <button
        className="complete-btn"
        onClick={complete}
        aria-label={done ? "Missão concluída" : "Concluir missão"}
      >
        {done ? <Icon name="check" /> : <span />}
      </button>
    </article>
  );
}

function MapScreen({ xp }: { xp: number }) {
  const [selected, setSelected] = useState(1);
  const zones = [
    {
      id: 0,
      name: "Santuário da Vitalidade",
      sub: "Descanso e equilíbrio",
      x: 48,
      y: 8,
      locked: true,
    },
    {
      id: 1,
      name: "Floresta da Disciplina",
      sub: "Região atual · 67%",
      x: 20,
      y: 31,
      locked: false,
    },
    { id: 2, name: "Cidade da Produtividade", sub: "8 de 12 missões", x: 63, y: 43, locked: false },
    {
      id: 3,
      name: "Biblioteca do Conhecimento",
      sub: "3 de 10 missões",
      x: 25,
      y: 64,
      locked: false,
    },
    { id: 4, name: "Montanhas da Força", sub: "Requer nível 15", x: 66, y: 78, locked: true },
  ];
  return (
    <div>
      <AppHeader title="Mapa da jornada" subtitle="Cada região desperta uma parte de você." />
      <div className="map-legend">
        <Badge>ATO II</Badge>
        <span>O CAMINHO DA CONSTÂNCIA</span>
      </div>
      <section className="world-map glass">
        <svg className="paths" viewBox="0 0 100 100">
          <path d="M48 13C25 18 18 25 20 34s34 1 43 12S36 55 25 66s32 1 41 14" />
          <path className="path-glow" d="M20 34c8 8 34 1 43 12S36 55 25 66" />
        </svg>
        {zones.map((z) => (
          <button
            key={z.id}
            onClick={() => !z.locked && setSelected(z.id)}
            className={`map-node ${selected === z.id ? "selected" : ""} ${z.locked ? "locked" : ""}`}
            style={{ left: `${z.x}%`, top: `${z.y}%` }}
          >
            <i>
              {z.locked ? (
                <Icon name="lock" size={17} />
              ) : (
                <Icon name={z.id === 1 ? "sword" : z.id === 2 ? "bolt" : "star"} size={20} />
              )}
            </i>
            <span>
              <strong>{z.name}</strong>
              <small>{z.sub}</small>
            </span>
          </button>
        ))}
        <div className="map-fog f1" />
        <div className="map-fog f2" />
      </section>
      <section className="region-card glass">
        <div className="region-top">
          <div>
            <span>REGIÃO SELECIONADA</span>
            <h3>{zones[selected].name}</h3>
          </div>
          <Badge tone="green">DESBLOQUEADA</Badge>
        </div>
        <p>Domine pequenos rituais diários e transforme intenção em ação consistente.</p>
        <div className="panel-title">
          <span>PROGRESSO DA REGIÃO</span>
          <strong>{selected === 1 ? "67" : "32"}%</strong>
        </div>
        <div className="progress">
          <i style={{ width: selected === 1 ? "67%" : "32%" }} />
        </div>
        <div className="region-stats">
          <span>
            <strong>8/12</strong> Missões
          </span>
          <span>
            <strong>{xp > 500 ? 3 : 2}</strong> Marcos
          </span>
          <span>
            <strong>420</strong> XP restante
          </span>
        </div>
        <button className="secondary">
          EXPLORAR REGIÃO <Icon name="arrow" size={17} />
        </button>
      </section>
    </div>
  );
}

function Character({ view, setView, completed, xp, profile, setProfile, attributeXp, level }: any) {
  const attrs = [
    ["FORÇA", 20 + Math.min(80, Math.floor((attributeXp.FORÇA || 0) / 20)), "Bem-estar"],
    ["INTELIGÊNCIA", 20 + Math.min(80, Math.floor((attributeXp.INTELIGÊNCIA || 0) / 20)), "Conhecimento"],
    ["DISCIPLINA", 20 + Math.min(80, Math.floor((attributeXp.DISCIPLINA || 0) / 20)), "Rotina"],
    ["VITALIDADE", 20 + Math.min(80, Math.floor((attributeXp.VITALIDADE || 0) / 20)), "Saúde"],
    ["FOCO", 20 + Math.min(80, Math.floor((attributeXp.FOCO || 0) / 20)), "Trabalho"],
  ];
  const classes = [
    { name: "Aprendiz", need: 0, desc: "O início de toda lenda." },
    { name: "Guerreiro", need: 500, desc: "Desbloqueado com 500 XP." },
    { name: "Erudito", need: 1200, desc: "Desbloqueado com 1.200 XP." },
    { name: "Paladino", need: 2500, desc: "Desbloqueado com 2.500 XP." },
  ];
  const currentClass = [...classes].reverse().find((c) => xp >= c.need) || classes[0];
  return (
    <div>
      <AppHeader title="Personagem" subtitle="Sua evolução, traduzida em poder." />
      <section className="character-hero glass">
        <div className="character-avatar">
          <div className="avatar-hex" style={{ background: `linear-gradient(145deg, ${profile.armor === "Carmesim" ? "#7d263d" : profile.armor === "Azul" ? "#174c75" : "#403775"}, #16182a)`, borderColor: profile.eyes === "Verde" ? "#55d6a0" : profile.eyes === "Âmbar" ? "#d7a64a" : "#7060d0" }}>
            <span>{profile.emblem || "LV"}</span>
          </div>
          <i className="lvl">{level}</i>
        </div>
        <div>
          <Badge tone="gold">{currentClass.name.toUpperCase()}</Badge>
          <h2>{profile.name}</h2>
          <p>Classe atual: {currentClass.name}</p>
          <div className="rank"><Icon name="trophy" size={16} /> {xp.toLocaleString("pt-BR")} XP TOTAL</div>
        </div>
      </section>
      <div className="tab-switch character-tabs">
        {["atributos", "conquistas", "estatísticas"].map((v) => <button key={v} className={view === v ? "active" : ""} onClick={() => setView(v)}>{v}</button>)}
      </div>
      {view === "atributos" && <>
        <section className="glass hero-customizer">
          <div className="section-heading"><div><span>OFICINA DO HERÓI</span><h3>Personalizar Leon</h3></div><Badge tone="green">SALVO AUTOMATICAMENTE</Badge></div>
          <label>Nome do personagem<input value={profile.name} maxLength={22} onChange={(e) => setProfile({ ...profile, name: e.target.value || "Leon Voss" })} /></label>
          <div className="custom-grid">
            <label>Cabelo<select value={profile.hair} onChange={(e) => setProfile({ ...profile, hair: e.target.value })}><option>Prateado</option><option>Preto</option><option>Branco</option><option>Castanho</option><option>Azul</option></select></label>
            <label>Olhos<select value={profile.eyes} onChange={(e) => setProfile({ ...profile, eyes: e.target.value })}><option>Violeta</option><option>Verde</option><option>Âmbar</option><option>Azul</option><option>Vermelho</option></select></label>
            <label>Armadura<select value={profile.armor} onChange={(e) => setProfile({ ...profile, armor: e.target.value })}><option>Ébano</option><option>Carmesim</option><option>Azul</option></select></label>
            <label>Emblema<select value={profile.emblem} onChange={(e) => setProfile({ ...profile, emblem: e.target.value })}><option>LV</option><option>⚔</option><option>✦</option><option>☾</option></select></label>
          </div>
          <p className="custom-note">A aparência escolhida fica salva neste dispositivo. Cabelo: {profile.hair} · Olhos: {profile.eyes}.</p>
        </section>
        <section className="glass class-panel">
          <div className="section-heading"><div><span>CAMINHO DE CLASSE</span><h3>Classes desbloqueáveis</h3></div></div>
          {classes.map((c) => <div className={`class-row ${xp >= c.need ? "unlocked" : "locked"}`} key={c.name}><div><strong>{c.name}</strong><small>{c.desc}</small></div><Badge tone={xp >= c.need ? "green" : "purple"}>{xp >= c.need ? "DESBLOQUEADA" : `${c.need - xp} XP restantes`}</Badge></div>)}
        </section>
        <div className="attribute-list">
          <div className="section-heading"><div><span>STATUS DO HERÓI</span><h3>Atributos</h3></div><small>Ganhos ao concluir missões</small></div>
          {attrs.map(([name, value, source]: any) => <div className="attribute glass" key={name}><div className="attribute-icon"><Icon name={name === "INTELIGÊNCIA" ? "star" : name === "FOCO" ? "bolt" : "sword"} /></div><div><div className="panel-title"><strong>{name}</strong><span>Nv. {Math.max(1, Math.floor(value / 10))}</span></div><div className="progress"><i style={{ width: `${value}%` }} /></div><small>{attributeXp[name] || 0} XP · {source}</small></div><b>{value}</b></div>)}
        </div>
      </>}
      {view === "conquistas" && <Achievements completed={completed} />}
      {view === "estatísticas" && <Statistics />}
    </div>
  );
}

function Achievements({ completed }: { completed: number }) {
  const items = [
    ["Primeiro Passo", "Conclua sua primeira missão.", "COMUM", true],
    ["Guerreiro Consistente", "Complete missões por 7 dias.", "RARO", true],
    ["Mente em Expansão", "Conclua 10 sessões de estudo.", "ÉPICO", false],
    ["Disciplina de Ferro", "Complete todas as diárias por 5 dias.", "LENDÁRIO", false],
  ];
  return (
    <div className="achievement-grid">
      {items.map(([name, desc, rarity, unlocked]: any) => (
        <article className={`achievement glass ${unlocked ? "" : "locked-card"}`} key={name}>
          <div className="achievement-icon">
            <Icon name={unlocked ? "trophy" : "lock"} />
          </div>
          <Badge tone={rarity === "LENDÁRIO" ? "gold" : "purple"}>{rarity}</Badge>
          <h3>{name}</h3>
          <p>{desc}</p>
          <span>{unlocked ? "DESBLOQUEADA" : `${Math.min(completed, 4)}/10 PROGRESSO`}</span>
        </article>
      ))}
    </div>
  );
}

function Statistics() {
  const bars = [42, 68, 53, 86, 61, 94, 72];
  return (
    <div className="statistics">
      <section className="glass chart-card">
        <div className="panel-title">
          <div>
            <span>XP CONQUISTADO</span>
            <h3>2.480 XP</h3>
          </div>
          <Badge tone="green">+18%</Badge>
        </div>
        <div className="bar-chart">
          {bars.map((v, i) => (
            <div key={i}>
              <i style={{ height: `${v}%` }} />
              <span>{["S", "T", "Q", "Q", "S", "S", "D"][i]}</span>
            </div>
          ))}
        </div>
      </section>
      <div className="stats-row">
        <div className="stat glass">
          <div>
            <span>MISSÕES</span>
            <strong>34</strong>
            <small> esta semana</small>
          </div>
        </div>
        <div className="stat glass">
          <div>
            <span>MELHOR DIA</span>
            <strong>Sábado</strong>
            <small> 7 missões</small>
          </div>
        </div>
      </div>
      <section className="glass category-chart">
        <span>CATEGORIAS MAIS DESENVOLVIDAS</span>
        {[
          ["Disciplina", 81],
          ["Trabalho", 76],
          ["Saúde", 72],
          ["Conhecimento", 64],
        ].map(([n, v]: any) => (
          <div key={n}>
            <div>
              <b>{n}</b>
              <span>{v}%</span>
            </div>
            <div className="progress">
              <i style={{ width: `${v}%`, background: categoryColors[n] || "#765cff" }} />
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}

function Inventory({ gold, buy }: { gold: number; buy: (n: string, p: number) => void }) {
  const rewards = [
    ["1 hora de videogame", "Tempo de lazer sem culpa.", 180, "DIGITAL"],
    ["Noite de cinema", "Escolha um filme e relaxe.", 260, "LAZER"],
    ["Café especial", "Uma pausa premium para recarregar.", 120, "SABOR"],
    ["Item da lista de desejos", "Uma conquista merece outra.", 800, "ÉPICO"],
  ];
  return (
    <div>
      <AppHeader title="Inventário" subtitle="Celebre sua evolução com recompensas reais." />
      <section className="wallet glass">
        <div>
          <span>SALDO DISPONÍVEL</span>
          <strong>
            <Icon name="coin" size={28} />
            {gold.toLocaleString("pt-BR")} <small>GOLD</small>
          </strong>
          <p>Conquistado com disciplina. Gaste sem culpa.</p>
        </div>
        <div className="coin-art">
          <Icon name="coin" size={44} />
        </div>
      </section>
      <div className="section-heading">
        <div>
          <span>LOJA PESSOAL</span>
          <h3>Recompensas</h3>
        </div>
        <button>
          <Icon name="plus" size={16} /> Criar
        </button>
      </div>
      <div className="shop-grid">
        {rewards.map(([name, desc, price, kind]: any, i) => (
          <article className="shop-card glass" key={name}>
            <div className={`shop-art a${i}`}>
              <Icon name={i === 0 ? "bolt" : i === 3 ? "trophy" : "star"} size={28} />
              <Badge tone={i === 3 ? "gold" : "purple"}>{kind}</Badge>
            </div>
            <h3>{name}</h3>
            <p>{desc}</p>
            <button disabled={gold < price} onClick={() => buy(name, price)}>
              <Icon name="coin" size={16} />
              {price} GOLD
            </button>
          </article>
        ))}
      </div>
      <section className="history glass">
        <div className="panel-title">
          <strong>HISTÓRICO RECENTE</strong>
          <button>Ver tudo</button>
        </div>
        <div>
          <span className="history-icon">
            <Icon name="check" size={16} />
          </span>
          <p>
            <strong>Episódio de série</strong>
            <small>Resgatado ontem, 20:40</small>
          </p>
          <b>-150</b>
        </div>
      </section>
    </div>
  );
}

function MissionModal({
  close,
  submit,
  mission,
}: {
  close: () => void;
  submit: (e: FormEvent<HTMLFormElement>) => void;
  mission?: Mission | null;
}) {
  return (
    <div className="modal-backdrop" onMouseDown={close}>
      <form className="modal glass" onSubmit={submit} onMouseDown={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <div>
            <span>{mission ? "EDITAR DESAFIO" : "NOVO DESAFIO"}</span>
            <h2>{mission ? "Editar missão" : "Criar missão"}</h2>
          </div>
          <button type="button" onClick={close}>
            <Icon name="close" />
          </button>
        </div>
        <label>
          Nome da missão
          <input name="title" required defaultValue={mission?.title ?? ""} placeholder="Ex: Ritual matinal" />
        </label>
        <label>
          Descrição
          <textarea name="description" required defaultValue={mission?.description ?? ""} placeholder="O que precisa ser feito?" />
        </label>
        <div className="form-grid">
          <label>
            Categoria
            <select name="category" defaultValue={mission?.category ?? "Saúde"}>
              <option>Saúde</option>
              <option>Conhecimento</option>
              <option>Disciplina</option>
              <option>Trabalho</option>
              <option>Bem-estar</option>
            </select>
          </label>
          <label>
            Horário
            <input type="time" name="time" defaultValue={mission?.time === "Livre" ? "" : mission?.time ?? ""} />
          </label>
        </div>
        <label>
          Tipo de missão
          <select name="type" defaultValue={mission?.type ?? "Diária"}>
            <option>Diária</option>
            <option>Semanal</option>
            <option>Especial</option>
          </select>
        </label>
        <label>
          Dificuldade
          <select name="difficulty" defaultValue={mission?.difficulty ?? "Fácil"}>
            <option>Fácil</option>
            <option>Médio</option>
            <option>Difícil</option>
          </select>
        </label>
        <button className="primary wide" type="submit">
          <Icon name={mission ? "check" : "plus"} /> {mission ? "SALVAR ALTERAÇÕES" : "ADICIONAR À JORNADA"}
        </button>
      </form>
    </div>
  );
}

function CalendarModal({ close, missions, completed }: any) {
  const days = ["SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM"];
  return (
    <div className="modal-backdrop" onMouseDown={close}>
      <section className="modal calendar-modal glass" onMouseDown={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <div>
            <span>ROTINA</span>
            <h2>Calendário da jornada</h2>
          </div>
          <button onClick={close}>
            <Icon name="close" />
          </button>
        </div>
        <div className="calendar-nav">
          <button>‹</button>
          <strong>20 — 26 de Maio</strong>
          <button>›</button>
        </div>
        <div className="week">
          {days.map((d, i) => (
            <div className={i === 2 ? "today" : ""} key={d}>
              <span>{d}</span>
              <b>{20 + i}</b>
              <i className={i < 4 ? "marked" : ""} />
            </div>
          ))}
        </div>
        <div className="agenda">
          <span>HOJE · 22 DE MAIO</span>
          {missions.slice(0, 4).map((m: Mission) => (
            <div key={m.id} className={completed.includes(m.id) ? "done" : ""}>
              <time>{m.time}</time>
              <i style={{ background: categoryColors[m.category] }} />
              <p>
                <strong>{m.title}</strong>
                <small>
                  {m.category} · +{m.xp} XP
                </small>
              </p>
              {completed.includes(m.id) && <Icon name="check" size={17} />}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function RewardModal({ reward, close }: { reward: Mission; close: () => void }) {
  const purchase = reward.gold < 0;
  return (
    <div className="modal-backdrop reward-backdrop">
      <div className="reward-modal glass">
        <div className="particle p1" />
        <div className="particle p2" />
        <div className="particle p3" />
        <div className="reward-burst">
          <Icon name={purchase ? "bag" : "trophy"} size={46} />
        </div>
        <Badge tone="gold">{purchase ? "RECOMPENSA RESGATADA" : "MISSÃO CONCLUÍDA"}</Badge>
        <h2>{reward.title}</h2>
        <p>
          {purchase
            ? "Aproveite. Você conquistou este momento."
            : "Uma vitória a mais na sua jornada."}
        </p>
        {!purchase && (
          <div className="reward-values">
            <span>
              <Icon name="bolt" />+{reward.xp} XP
            </span>
            <span>
              <Icon name="coin" />+{reward.gold} GOLD
            </span>
          </div>
        )}
        <button className="primary wide" onClick={close}>
          CONTINUAR JORNADA
        </button>
      </div>
    </div>
  );
}
